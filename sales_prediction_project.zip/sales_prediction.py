import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression

# Load dataset
data = pd.read_csv('sales_data.csv')
data['MonthNumber'] = np.arange(1, len(data) + 1)

# Prepare features and labels
X = data[['MonthNumber']]  # Feature
y = data['Sales']          # Target

# Split data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Train model
model = LinearRegression()
model.fit(X_train, y_train)

# Predict
y_pred = model.predict(X_test)

# Visualize results
plt.scatter(X, y, color='blue', label='Actual Sales')
plt.plot(X, model.predict(X), color='red', linewidth=2, label='Predicted Sales Trend')
plt.xlabel('Month Number')
plt.ylabel('Sales')
plt.title('Sales Prediction using Linear Regression')
plt.legend()
plt.grid(True)
plt.show()

# Predict future sales
future_months = np.array([[13], [14], [15]])  # Predict next 3 months
future_sales = model.predict(future_months)
print(f"Predicted sales for next months: {future_sales}")
